YAM Logistics - Dangerous goods labels & marks (free printable artwork)
https://www.yamlogistics.com/dg-labels.html

pdf/   A4 sheets with each label at actual size. Print at 100% / "Actual size".
png/   ~300 dpi images for label printers and documents.
svg/   Vector artwork in millimetres, for printers and designers.
yam-dg-labels-all.pdf  Every label in one file.

Hazard label artwork follows the UN Model Regulations figures (public domain UN/ADR artwork).
Handling labels and marks are redrawn to the ICAO Technical Instructions / IATA DGR figures.
Always check against the current IATA DGR edition and operator variations before use.
The shipper is responsible for correct classification, packing, marking and labelling.

Need help with a dangerous goods shipment? WhatsApp +91 92125 58167
